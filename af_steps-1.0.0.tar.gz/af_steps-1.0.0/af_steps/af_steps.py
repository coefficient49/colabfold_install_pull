from af_steps.utils import *


def run_alignment(fasta_file, target_directory):
	command = f"colabfold_search uniref --db1 uniref30_2302_db --db3 colabfold_envdb_202108_db --db-load-mode 2 {fasta_file} ~/db/ {target_directory}"
	try:
		proc = subprocess.check_output(command, stderr=subprocess.STDOUT)
		# do something with output
	except subprocess.CalledProcessError as e:
		logging.error(e)
		return str(e)

	return target_directory


def run_folding(fasta_file, target_directory):
	command = f"colabfold_search uniref --db1 uniref30_2302_db --db3 colabfold_envdb_202108_db --db-load-mode 2 {fasta_file} ~/db/ {target_directory}"
	try:
		proc = subprocess.check_output(command, stderr=subprocess.STDOUT)
		# do something with output
	except subprocess.CalledProcessError as e:
		logging.error(e)
		return str(e)

	return target_directory



def get_args():

    parser = argparse.ArgumentParser(
        prog="af_steps",
        usage="wrapper around AF and ColabFold"
    )
    parser.add_argument(
        "-in",
        "--input",
        required=True,
        dest="input"
    )

    parser.add_argument(
        "-m",
        "--mode",
        nargs=1,
        choices=["search","fold"],
        dest="mode"
    )

    args = parser.parse_args()
    return args


def main():
    args = get_args()
    
    if args.mode == "search":
        input_file = args.input # fastas/xyz.fasta
        filename_wo_ext = Path(input_file).basename.suffix("")

        output_directory =  Path("msas",filename_wo_ext)# msas/xyz/
        output_directory = str(output_directory)
		run_alignment(input_file, output_directory)

    else:
        input_file = args.input # msas/xyz.asm
        output_directory = args.input # pdbs/xyz/
	