import boto3
import sys, os
import subprocess
import argparse,logging
from pathlib import Path

def get_fasta_file():
    bucket = "jchen-af-storage"
    folder = "fastas_new"
    s3 = boto3.resource("s3")
    s3_bucket = s3.Bucket(bucket)
    files_in_s3 = sorted([f.key.split(folder + "/")[1] for f in s3_bucket.objects.filter(Prefix=folder).all()])
    return [x for x in files_in_s3 if x.endswith("fasta")]



def download_file(file_name,bucket = "jchen-af-storage",folder="fastas_new"):
    """
    Download a file from s3 and then delete it in the bucket to prevent running again
    """
    s3 = boto3.client("s3")
    s3.download_file(bucket, f"{folder}/{file_name}", f'fastas_2/{file_name}')
    response = s3.delete_object( Path=f"{folder}/{file_name}")

    return f'fastas_2/{file_name}'

def upload_file(file_name, bucket="jc-af-storage", folder="fastas_done",object_name=None):
    """Upload a file to an S3 bucket
    
    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param object_name: S3 object name. If not specified then file_name is used
    :return: True if file was uploaded, else False
    """
    
    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = os.path.basename(file_name)

    # Upload the file
    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file(file_name, bucket, f"{folder}/{object_name}")
    except ClientError as e:
        logging.error(e)
        return False
    return f"{bucket}/{folder}/{object_name}"
